<?php

namespace Drupal\wormchat\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * Setup controller for device provisioning and firmware flashing.
 */
class WormSetupController extends ControllerBase {

  /**
   * Displays the device setup page with ESP Web Tools integration.
   */
  public function setupPage() {
    $user = \Drupal::currentUser();

    // Redirect if not logged in (shouldn't happen due to routing requirement, but safety check)
    if ($user->isAnonymous()) {
      return [
        '#markup' => '<p>' . $this->t('Please log in to access device setup.') . '</p>',
      ];
    }

    // Check if user already has a device token
    $has_token = FALSE;
    $device_token = \wormchat_get_device_token($user->id());
    if (!empty($device_token)) {
      $has_token = TRUE;
    }

    return [
      '#type' => 'markup',
      '#markup' => $this->buildSetupPageMarkup($user, $has_token),
      '#attached' => [
        'library' => [
          'wormchat/esp-web-tools',
        ],
        'drupalSettings' => [
          'wormchat' => [
            'setupApiUrl' => '/api/wormchat/device-provision',
            'userId' => $user->id(),
            'hasToken' => $has_token,
          ],
        ],
      ],
    ];
  }

  /**
   * Builds the HTML markup for the setup page.
   */
  private function buildSetupPageMarkup($user, $has_token) {
    $html = '<div class="worm-setup-container">';
    $html .= '<h1>' . $this->t('IoT Device Setup') . '</h1>';

    if ($has_token) {
      $html .= '<div class="alert alert-success">';
      $html .= '<p>' . $this->t('✓ Your device is already configured!') . '</p>';
      $html .= '<p>' . $this->t('Your worm monitor is connected and sending data.') . '</p>';
      $html .= '</div>';
    } else {
      $html .= '<div class="setup-instructions">';
      $html .= '<h2>' . $this->t('Flash Your ESP32-C3 Device') . '</h2>';
      $html .= '<p>' . $this->t('Follow these steps to set up your worm monitor sensor:') . '</p>';

      $html .= '<ol>';
      $html .= '<li>' . $this->t('Connect your ESP32-C3 device to your computer via USB') . '</li>';
      $html .= '<li>' . $this->t('Click the button below to flash the firmware') . '</li>';
      $html .= '<li>' . $this->t('The device will connect to your home WiFi') . '</li>';
      $html .= '<li>' . $this->t('Your access token will be automatically stored') . '</li>';
      $html .= '<li>' . $this->t('You\'re ready to monitor your worms!') . '</li>';
      $html .= '</ol>';

      $html .= '<div id="esp-flash-container" class="esp-web-tools-container">';
      $html .= '<esp-web-install-button manifest="' . base_path() . 'modules/custom/wormchat/assets/esp-manifest.json"></esp-web-install-button>';
      $html .= '</div>';

      $html .= '<div id="setup-status" class="setup-status" style="display: none;">';
      $html .= '<p id="status-message"></p>';
      $html .= '</div>';
      $html .= '</div>';
    }

    $html .= '</div>';
    return $html;
  }

  /**
   * API endpoint to receive provisioning token from ESP32.
   *
   * Expected POST body:
   * {
   *   "token": "access_token_from_thingsboard"
   * }
   */
  public function provisionDevice(Request $request) {
    $user = \Drupal::currentUser();

    // Check if user is authenticated
    if ($user->isAnonymous()) {
      return new JsonResponse(
        ['error' => $this->t('Unauthorized - please log in')],
        401
      );
    }

    // Get the JSON payload
    try {
      $data = json_decode($request->getContent(), TRUE);
    } catch (\Exception $e) {
      \Drupal::logger('wormchat')->error('Invalid JSON in provisioning request: @error', ['@error' => $e->getMessage()]);
      return new JsonResponse(
        ['error' => $this->t('Invalid request format')],
        400
      );
    }

    // Validate token exists
    if (empty($data['token'])) {
      \Drupal::logger('wormchat')->warning('Provisioning request missing token');
      return new JsonResponse(
        ['error' => $this->t('Token is required')],
        400
      );
    }

    $token = trim($data['token']);

    // Store token in secure key-value store
    try {
      if (\wormchat_set_device_token($user->id(), $token)) {
        \Drupal::logger('wormchat')->info(
          'Device provisioned for user @uid',
          ['@uid' => $user->id()]
        );

        return new JsonResponse(
          [
            'success' => TRUE,
            'message' => $this->t('Device provisioned successfully!'),
            'user_id' => $user->id(),
          ],
          200
        );
      } else {
        \Drupal::logger('wormchat')->error(
          'Failed to store device token for user @uid',
          ['@uid' => $user->id()]
        );
        return new JsonResponse(
          ['error' => $this->t('Failed to store device token')],
          500
        );
      }
    } catch (\Exception $e) {
      \Drupal::logger('wormchat')->error(
        'Error provisioning device: @error',
        ['@error' => $e->getMessage()]
      );
      return new JsonResponse(
        ['error' => $this->t('Failed to provision device: @message', ['@message' => $e->getMessage()])],
        500
      );
    }
  }

}
